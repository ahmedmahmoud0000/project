
"use strict";

module.exports = {
  srv: require('./srv/_index.js')
};
